import os
import time
import random
import sys
from playwright.sync_api import sync_playwright

def init_files():
    # 自动创建私信文件和联系名单
    if not os.path.exists("IG已联系名单.txt"):
        with open("IG已联系名单.txt", "w", encoding="utf-8") as f: pass
    if not os.path.exists("IG私信内容.txt"):
        with open("IG私信内容.txt", "w", encoding="utf-8") as f: f.write("Hi! Nice to meet you. Have a great day!")
    
    # 自动创建本地浏览器数据文件夹（完全独立）
    if not os.path.exists("IG_Browser_Data"):
        os.makedirs("IG_Browser_Data")

def load_contacted_list():
    if os.path.exists("IG已联系名单.txt"):
        with open("IG已联系名单.txt", "r", encoding="utf-8") as f:
            return set(line.strip() for line in f if line.strip())
    return set()

def save_to_contacted_list(user_id):
    with open("IG已联系名单.txt", "a", encoding="utf-8") as f:
        f.write(f"{user_id}\n")

def main():
    init_files()
    print("====================================")
    print("🕵️ IG 幽灵模式启动，正在连接你开好的独立浏览器...")
    
    try:
        p = sync_playwright().start()
        # 连接用 .bat 启动的 9223 端口
        browser = p.chromium.connect_over_cdp("http://localhost:9223")
        page = browser.contexts[0].pages[-1]
        page.bring_to_front()
        print("✅ 连接成功！\n")
    except Exception as e:
        print(f"❌ 连接失败！\n报错: {e}")
        print("💡 请确认你是不是双击了最新改好的【启动浏览器.bat】，并在里面打开了 IG 网页？")
        input("按回车退出...")
        return

    contacted_users = load_contacted_list()
    print(f"🧠 已加载历史记录：曾经操作过 {len(contacted_users)} 个 IG 用户。")

    # 读取自定义私信内容
    try:
        with open("IG私信内容.txt", "r", encoding="utf-8") as f: 
            dm_text = f.read().strip()
    except:
        dm_text = "Hi! Nice to meet you."

    start_time = time.time()
    empty_scroll_count = 0 

    print("♾️ 开始扫描页面（见人就点关注并发私信）...\n")
    
    while True:
        if time.time() - start_time > 180:
            print("\n⏸️ 连续操作 3 分钟，自动休息 60 秒防封...")
            time.sleep(60)
            start_time = time.time()
            empty_scroll_count = 0

        new_page = None
        try:
            page.bring_to_front()
            time.sleep(1)
            
            # IG 的按钮通常是 "关注" 或 "Follow"
            elements = page.locator('button:has-text("关注"), button:has-text("Follow"), div[role="button"]:has-text("关注"), div[role="button"]:has-text("Follow")')
            count = elements.count()

            if count == 0:
                empty_scroll_count += 1
                print(f"  [⏳] 未发现关注按钮，向下滚动加载(第{empty_scroll_count}次)...")
                page.mouse.move(500, 500)
                page.mouse.wheel(0, 1200)
                
                if empty_scroll_count >= 5:
                    print("  [💤] 到底了或网络慢，休息 10 秒...")
                    time.sleep(10)
                    empty_scroll_count = 0 
                else:
                    time.sleep(3)
                continue

            target_el = None
            target_href = None
            target_id = None

            for i in range(count):
                el = elements.nth(i)
                if not el.is_visible(): continue
                
                try:
                    # 寻找距离按钮最近的用户链接
                    user_link = el.locator('xpath=ancestor::div//a[contains(@href, "/")]').first
                    if not user_link.is_visible(): continue
                    href = user_link.get_attribute("href")
                except: 
                    continue
                
                if not href or href.count('/') < 2:
                    continue
                
                user_id = href.strip('/').split('/')[-1]
                
                # 过滤掉 IG 系统页面
                if len(user_id) < 2 or user_id in ['explore', 'reels', 'direct']:
                    continue

                if user_id not in contacted_users:
                    target_el = el
                    target_href = f"https://www.instagram.com/{user_id}/"
                    target_id = user_id
                    break 
            
            # 如果当前屏幕全是关注过的人
            if not target_el:
                empty_scroll_count += 1
                print("  [⏭️] 当前屏全是已处理过的，向下滚动...")
                page.mouse.move(500, 500)
                page.mouse.wheel(0, 1200)
                time.sleep(3)
                continue

            empty_scroll_count = 0 
            print(f"\n--- 锁定新目标: {target_id} ---")
            
            # 1. 在列表页点关注
            try:
                target_el.click(force=True, timeout=5000)
                print("  [√] 列表页已点关注")
                save_to_contacted_list(target_id)
                contacted_users.add(target_id)
            except:
                print("  [!] 关注失败（可能点慢了），跳过")
                save_to_contacted_list(target_id)
                contacted_users.add(target_id)
                continue
            
            time.sleep(random.uniform(2, 4))

            # 2. 进入个人主页
            try:
                new_page = browser.contexts[0].new_page()
                new_page.goto(target_href, timeout=30000)
                new_page.bring_to_front()
                new_page.wait_for_timeout(random.uniform(4000, 6000)) 
            except Exception as e:
                print(f"  [❌] 进主页失败")
                if new_page: new_page.close()
                continue

            print(f"  ✅ 进入主页，执行操作！")
            
            # 3. 下滑浏览主页
            try:
                for _ in range(random.randint(2, 3)):
                    new_page.mouse.move(random.randint(200, 800), random.randint(200, 600))
                    new_page.mouse.wheel(0, random.randint(400, 800))
                    time.sleep(random.uniform(1.0, 2.0))
            except: 
                pass

            # 4. 点赞最新帖子
            try:
                like_btn = new_page.locator('svg[aria-label="赞"], svg[aria-label="Like"], span[aria-label="赞"], span[aria-label="Like"]').first
                if like_btn.is_visible(timeout=3000):
                    like_btn.locator("xpath=..").click(force=True)
                    print("  [👍] 已点赞最新帖子")
                    time.sleep(random.uniform(2, 4))
            except: 
                pass

            # 5. 发送私信 (DM)
            try:
                msg_btn = new_page.locator('div[role="button"]:has-text("发消息"), div[role="button"]:has-text("Message")').first
                if msg_btn.is_visible(timeout=4000):
                    msg_btn.click(force=True)
                    new_page.wait_for_timeout(4000) 
                    
                    msg_box = new_page.locator('div[aria-label="Message"], div[aria-label="消息"], p:has-text("Message...")').last
                    
                    if msg_box.is_visible(timeout=4000):
                        msg_box.click(force=True)
                        time.sleep(1.5)
                        # 拟人化逐字输入
                        for char in dm_text:
                            new_page.keyboard.type(char)
                            time.sleep(random.uniform(0.05, 0.15))
                        time.sleep(1.5)
                        new_page.keyboard.press("Enter") 
                        print(f"  [🚀] 私信发送成功")
                        time.sleep(3)
            except: 
                pass

            print("  [←] 完成，返回。\n")

        except Exception as e:
            print(f"  [⚠️ 网页异常或网络慢，跳过当前循环。]")
            time.sleep(3)
        finally:
            if new_page:
                try: 
                    new_page.close()
                    page.bring_to_front() 
                except: pass

        # 每次操作完休息 8-15 秒
        time.sleep(random.uniform(8, 15))

if __name__ == "__main__":
    main()