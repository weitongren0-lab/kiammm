@echo off
taskkill /F /IM chrome.exe /T >nul 2>&1
start "" "C:\Program Files\Google\Chrome\Application\chrome.exe" --remote-debugging-port=9223 --user-data-dir="%~dp0IG_Browser_Data"